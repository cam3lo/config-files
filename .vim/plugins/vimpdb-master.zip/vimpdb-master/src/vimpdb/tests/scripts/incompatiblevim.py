print "-clientserver -python"
