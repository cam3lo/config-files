print "VIM"
